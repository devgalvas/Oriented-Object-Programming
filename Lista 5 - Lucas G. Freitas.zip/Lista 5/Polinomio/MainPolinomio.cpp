#include "Polinomio.h"
#include "Polinomio.cpp"
#include <iostream>

using namespace std;

int main ()
{
    Poli p4;
    Poli p6;
    Poli result;

    int index = 0;

    cout << endl;
    cin >> p4 >> p6;
    cout << p4 << p6 << endl;;

    /* 
        Havia tido um erro com o simbolo de igualdade, ele nao deixava eu atribuir
        um valor de igual a essa soma, por ela ser uma alocacao de memoria temporaria,
        para resolver, modifiquei o operador de = colocando um const, que resolveu meu 
        problema por falar pro compilador que isso nao alteraria meu valor original dos 
        objetos em questao. 
    */
    result = p4 + p6;
    cout << "=== Operacoes ===" << endl;
    cout << "Soma: " << result << endl;

    result = p6 - p4;
    cout << "Subtracao: " << result << endl;

    result = p6.derivative();
    cout << "Derivada de " << p6 << " = " << result << endl;

    result = p4.derivative();
    cout << "Derivada de " << p4 << " = " << result << endl;

    return 0;
}
