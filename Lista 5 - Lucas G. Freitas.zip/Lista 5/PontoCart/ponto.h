#include <iostream>

#ifndef PONTO_H
#define PONTO_H

using namespace std;

class Ponto
{
private:
    double x, y;

public:
    Ponto(double xx = 0, double yy = 0) : x{xx}, y{yy} {}
    ~Ponto() {}

    // metodos de acesso
    double getX() {return x;}
    double getY() {return y;}

    // primeiro operando eh do tipo Ponto
    Ponto operator+(Ponto&);
    Ponto operator+(int);

    Ponto operator-(Ponto&);
    Ponto operator-(int);

    // Primeiro operando do tipo int
    friend Ponto operator+(int, Ponto&);

    // operadores unarios
    bool operator!() const;

    Ponto& operator++(); // pre-incremento
    Ponto operator++(int); //pos incremento

    Ponto& operator--(); // pre-incremento
    Ponto operator--(int); //pos incremento

    explicit operator int(); // conversao pra int
    bool operator==(Ponto&);
    bool operator!=(Ponto&);

    friend istream& operator>>(istream& in, Ponto& p)
    {   
        cout << "Insira as coordenadas x e y, respectivamente: "; 
        in >> p.x >> p.y;
        return in;
    }   

    friend ostream& operator<<(ostream& out, Ponto& p)
    {
        out << "( " << p.x << " , " << p.y << " )" << endl;
        return out;
    }

};

#endif
