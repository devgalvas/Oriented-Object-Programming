#include "ponto.h"
#include "ponto.cpp"
#include <iostream>

using namespace std;

int main ()
{
    Ponto p1, p2;
    Ponto op;
    Ponto temp1, temp2;

    cin >> p1;
    cout << "P1: " << p1 << endl;

    cin >> p2;
    cout << "P2: " << p2 << endl;

    // operacoes
    op = p1 + p2;
    cout << "Soma: " << op;

    op = p1 - p2;
    cout << "Subtracao: " << op;

    cout << "P1 = P2? "<< (p1 == p2) << endl;

    cout << "P1 != P2? "<< (p1 != p2) << endl;

    // Incremetando
    temp1 = p1;
    ++temp1;

    cout << "Pos-incremento p1: " << temp1;
    
    temp2 = p2;
    ++temp2;
    cout << "Pos-incremento p2: " << temp2;


    return 0;
}