#include <iostream>
#include <cmath>
#include "ponto.h"

using namespace std;

Ponto Ponto::operator+(Ponto& p)
{
    int xx = x + p.x;
    int yy = y + p.y;

    return Ponto(xx, yy);
}

Ponto Ponto::operator+(int v)
{
    int xx = x + v;
    int yy = y + v;

    return Ponto(xx, yy);
}

bool Ponto::operator!() const
{
    if(x == 0 && y == 0) return true;
    else return false;
}

Ponto& Ponto::operator++()
{
    x++;
    y++;
    return *this;
}

Ponto Ponto::operator++(int value)
{
    Ponto temp = (*this);
    ++(*this);
    return temp;
}

Ponto Ponto::operator-(Ponto& p)
{
    int xx = x - p.x;
    int yy = y - p.y;

    return Ponto(xx, yy);
}

Ponto Ponto::operator--(int value)
{
    Ponto temp = (*this);
    --(*this);
    return temp;
}

Ponto& Ponto::operator--()
{
    x--;
    y--;
    return *this;
}

Ponto::operator int()
{
    return sqrt(pow(x, 2) + pow(y, 2));
}

bool Ponto::operator==(Ponto& p)
{
    if(x == p.x && y == p.y) return true;
    else return false;
}

bool Ponto::operator!=(Ponto& p)
{
    if(x != p.x || y != p.y) return true;
    else return false;

    /* Ou: 
        if(!(*this == p)) return true; else return false;
    */
}
